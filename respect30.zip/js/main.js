$(".footer-top").click(function () {
 $("body,html").animate({
  scrollTop: 0
 }, 800);
});
$('.home-slider').slick({
 slidesToShow: 1,
 slidesToScroll: 1,
 arrows: true,
 fade: true,
 slide: '.home-slide',
 prevArrow: ".home-slider-prev",
 nextArrow: ".home-slider-next"
});
$('.home-when-slider').slick({
 slidesToShow: 4,
 slidesToScroll: 1,
 arrows: true,
 dots: true,
 prevArrow: ".home-when-prev",
 nextArrow: ".home-when-next",
 responsive: [{
  breakpoint: 992,
  settings: {
   slidesToShow: 3
  }
 },
 {
  breakpoint: 768,
  settings: {
   slidesToShow: 2
  }
 },
 {
  breakpoint: 576,
  settings: {
   slidesToShow: 1
  }
 }]
});
$('.pay-slider').slick({
 slidesToShow: 4,
 slidesToScroll: 1,
 arrows: true,
 dots: true,
 prevArrow: ".pay-prev",
 nextArrow: ".pay-next",
 responsive: [{
  breakpoint: 1200,
  settings: {
   slidesToShow: 3
  }
 },
 {
  breakpoint: 992,
  settings: {
   slidesToShow: 2
  }
 },
 {
  breakpoint: 576,
  settings: {
   slidesToShow: 1
  }
 }]
});
$('.order-slider').slick({
 slidesToShow: 3,
 slidesToScroll: 1,
 arrows: true,
 dots: true,
 prevArrow: ".order-prev",
 nextArrow: ".order-next",
 responsive: [{
  breakpoint: 992,
  settings: {
   slidesToShow: 2
  }
 },
 {
  breakpoint: 768,
  settings: {
   slidesToShow: 1
  }
 },
 {
  breakpoint: 576,
  settings: {
   slidesToShow: 1
  }
 }]
});
$(".home-brand-block").on("click", function (e) {
 e.preventDefault();
 $(".home-brand-wrap2").hide();
 $(".home-brand-wrap3").show();
});
$(".home-brand-back").on("click", function (e) {
 e.preventDefault();
 $(".home-brand-wrap3").hide();
 $(".home-brand-wrap2").show();
});
$(".quest-top-block-title").on("click", function () {
 $(".quest-top-block-descr").not($(this).next(".quest-top-block-descr")).removeClass("quest-top-block-descr-active");
 $(".quest-top-block").not($(this).closest(".quest-top-block")).removeClass("quest-top-block-active");
 $(".quest-top-block-title").not($(this)).removeClass("quest-top-block-title-active");
 $(this).next(".quest-top-block-descr").toggleClass("quest-top-block-descr-active");
 $(this).toggleClass("quest-top-block-title-active");
 $(this).closest(".quest-top-block").toggleClass("quest-top-block-active");
});